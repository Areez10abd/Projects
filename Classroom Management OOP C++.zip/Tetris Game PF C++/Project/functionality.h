/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */

//---Piece Starts to Fall When Game Starts---//
void fallingPiece(float& timer, float& delay,int& delta_x,int& colorNum){
    if (timer>delay){
        for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            point_1[i][1]+=1;                   //How much units downward
            point_1[i][0]+=delta_x;
        }
        delta_x = 0;
        if (!anamoly()){
            for(int i=0 ; i<4 ; i++)
                gameGrid[point_2[i][1]][point_2[i][0]]= colorNum;
            
            colorNum = 1+rand()%7;
            int n=rand()%7;
                for (int i=0;i<4;i++){
                    point_1[i][0] = BLOCKS[n][i] % 2;
                    point_1[i][1] = BLOCKS[n][i] / 2;
                }
        delay = 0.3;
        }
        timer=0;
    }
}

/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///
void pieceRotate()
{
    int center[2];
    center[0] = point_1[1][0];
    center[1] = point_1[2][1];

    for(int i=0;i<4;i++){
        int x = point_1[i][1]-center[1];
        int y = point_1[i][0]-center[0];
        point_1[i][0] = center[0]-x;
        point_1[i][1] = center[1]+y;
    }
}
using namespace sf;
void over(RenderWindow& window,int& points){


    for(int i=0;i<N;i++){
        if(gameGrid[0][i] != 0){
            window.close();
            std::cout << "Game Over!!!"<<std::endl;
            std::cout << "Your points: "<< points << std::endl;
        }
    }


}

void rowComplete(){
    bool rowComp = false;

    for(int i=0;i<M;i++){
        rowComp = true;
        for(int j=0;j<N;j++){
            if(gameGrid[i][j] == 0)
                rowComp=false;
        }
        if(rowComp == true){
            for(int j=0;j<N;j++){
               for(int k=i;k>0;k--)
                    gameGrid[k][j]=gameGrid[k-1][j];     
            }
        }
    }

    
}

///*** YOUR FUNCTIONS END HERE ***///
/////////////////////////////////////