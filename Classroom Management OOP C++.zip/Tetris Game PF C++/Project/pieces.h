/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */

int BLOCKS[][4] = {{1,3,5,7},{2,4,5,7},{3,5,4,6},{3,5,7,6},{2,4,6,7},{2,3,4,5},{2,4,5,6}};