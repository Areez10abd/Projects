#!/usr/bin/env python
# coding: utf-8

# In[2]:


#This is group Group6 of the discrete project
#Our members are Ammar Yasir 20I-0501,Umar Qazi 20I-0968,Daniyal Imran 20I-0940
#We have Web scrapped from the Three univeristies GIK,Nust,and Comsats.
#we used juptyer in anaconda


# In[1]:


import pandas as pd #libary pandas


# In[2]:


import requests #libary of requests websites


# In[3]:


from bs4 import BeautifulSoup #libary of beautiful soup


# In[4]:


import spacy
from spacy import displacy
from collections import Counter #three libaries for visulasation
pd.set_option("max_rows", 400)
pd.set_option("max_colwidth", 400)


# In[5]:


import networkx
import matplotlib.pyplot as plt


# In[8]:


#Part1 of the project:


# In[6]:


#The first webpage:


# In[7]:


response = requests.get("https://giki.edu.pk/admissions/admissions-undergraduates/ugrad-aid-scholarships/") #The first webpage


# In[8]:


response #we are getting the repsonse from our first webpage


# In[9]:


firstUniversity_Webpage = response.text #we have stored the data of the first webpage into a variable


# In[10]:


Document = BeautifulSoup(firstUniversity_Webpage, "html.parser") #creating the beutiful soup and parcersing it


# In[11]:


Document


# In[12]:


#The second webpage:


# In[13]:


response = requests.get("https://giki.edu.pk/admissions/admissions-undergraduates/ugradhow-to-apply/") #The second webpage


# In[14]:


response #we are getting the repsonse from our second webpage


# In[15]:


firstUniversity_Webpage1 = response.text #we have stored the data of the second webpage into a variable


# In[16]:


Document1 = BeautifulSoup(firstUniversity_Webpage1, "html.parser") #creating the beutiful soup and parcersing it


# In[17]:


Document1


# In[18]:


#The third webpage:


# In[19]:


reponse = requests.get("https://www.comsats.edu.pk/AboutCiit/RectorsProfile.aspx") #The third webpage


# In[20]:


response  #we are getting the repsonse from our third webpage


# In[21]:


secondUniversity_Webpage = response.text #we have stored the data of the third webpage into a variable


# In[22]:


Document2 = BeautifulSoup(secondUniversity_Webpage, "html.parser") #creating the beutiful soup and parcersing it


# In[23]:


Document2


# In[27]:


#The fourth webpage:


# In[24]:


response = requests.get("https://www.comsats.edu.pk/AboutCIIT/history.aspx") #The fourth webpage


# In[25]:


response


# In[26]:


secondUniversity_Webpage1 = response.text #we have stored the data of the fourth webpage into a variable


# In[27]:


Document3 = BeautifulSoup(secondUniversity_Webpage1, "html.parser") #creating the beutiful soup and parcersing it


# In[28]:


Document3


# In[29]:


#The fiveth webpage:


# In[30]:


response = requests.get("https://rni.nust.edu.pk/about-us/pro-rector-message/") #The fiveth webpage


# In[31]:


response


# In[32]:


thirdUniversity_Webpage = response.text #we have stored the data of the fiveth webpage into a variable


# In[33]:


Document4 = BeautifulSoup(thirdUniversity_Webpage, "html.parser")  #creating the beutiful soup and parcersing it


# In[34]:


Document4


# In[35]:


#Part2 of the project:


# In[36]:


#!pip install -U spacy (just wanted to install this libary)


# In[37]:


#!python -m spacy download en_core_web_sm (just wanted to install this libary)


# In[38]:


nlp = spacy.load('en_core_web_sm') #loading the model


# In[39]:


#The first webpage:


# In[40]:


visual = """The following scholarships Financial Assistance has been approved by Executive Committee for the FY 2021-22. President SOPREST Scholarship has been increased to Rs. 30 M from Rs. 15 (M) . Merit Scholarship is increased from 10 seats to 20 seats (70:30 Engineering& Management Sciences respectively) Financial assistance to top female students is increased from 5 seats to 10 seats(70:30 Engineering & Management Sciences respectively) General financial assistance is increased from existing 10% to 20% of net revenue estimated to be collected from the fresh batch. Following full or partial Scholarships and Financial Assistance are likely to be available for those to be admitted in the academic year 2021-2022. Scholarships	Qualification/Conditions/Criteria	No. of Scholarships GIK Merit Scholarship	Top Position Holders in Engineering Test	14 GIK Merit Scholarship	Top Position Holders in Management Sciences Test	06 Chief Minister Khyber Pakhtunkhwa	KP domiciled with annual family income less than Rs. 600,000.	20Dr. H.M. Yusaf Scholarship	Financially most needy student.	01Dr. Razia Raouf Scholarship	Female student top of the merit list	01Frontier Education Foundation	KP Domiciled	06GIK Alumni Association	Needy GIK students	30Govt. of Balochistan	 Balochistan Domiciled	02Ihsan Trust Qarze Hasna	 	20Lucky Cement Pvt.Ltd	Pakistani National with preference to KP domiciled on need-cum-merit basis.	01HBL Platinium Scholarship	Need-cum-merit Basis	01Punjab Educational Endowment Fund	Punjab domiciled with annual family gross income less than 360,000.	10Sindh Endowment Fund Scholarship	Sindh domiciled	05Financial Assistance(Interest Free Loan)  by GIK Institute	Need-Cum-Merit Basis	35Chief Minister’s Educational Endowment Fund Scholarship	KP domiciled with annual family income less than Rs. 1,200,000	02Squeaks Foundation	Female student from KP	01Candidates can apply online for Punjab Educational Endowment Fund (PEEF) , Chief Minister Khyber Pakhtunkhwa Scholarships and  Financial Assistance (Interest Free Loan). Remaining scholarships can be applied for after joining the Institute.Continuation of scholarships is dependent on satisfactory academic performance of the concerned student and the policies of the donor agencies.Financial Aid/LoanThe Institute provides liberal financial assistance to the needy and deserving students covering full or partial tuition fee in the form of interest fee loan. Each year about 40-50 students get benefit of financial assistance. Students desirous of getting financial assistance may submit financial assistance form available at the Institute website along with the admission form (please add Rs. 500 as financial assistance processing fee in addition to Rs. 5,500 of admission procession fee). Applicants will be informed about award of financial assistance along with admission offer.The Financial Loan is returnable in easy six-monthly installments from one year after completion of graduation. For more information, contact  muhammad.israr@giki.edu.pk, telephone number (0938) 281026 Ext: 2342Those who apply for financial assistance will be informed at the time of admission whether or not their request has been acceded to. An applicant who has secured admission on basis of merit but whose request for financial assistance is not approved would be admitted on payment of full tuition fee.Financial assistance for needy students is also available from the GIK Alumni Association. Contact the GIK Admission Office for details.PEEF ScholarshipTotal seats 10, Scholarship amount Rs.300, 000/-Detail CriteriaStudents must have domicile of the Punjab Province.Students must have secured at least 60% marks (first division) in their Intermediate    Annual Examination and must have enrolled in the graduate level degree program in the same year (2020) as they have passed such Intermediate Annual Examination.Students must have passed the above mentioned examination through any Board of Intermediate and Secondary Education of Punjab or the Federal Board of Intermediate and Secondary Education: (a) from a government institution (students of Federal Government Institutions situated within geographical boundaries of Punjab are eligible), or (b) appearing as a private candidate, or (c) from a private affiliated institution.The annual household family income of each of the Students must not be more than Rs. 360,000/- (Rupees Three Hundred Sixty Thousand Only).The Students must also qualify under the criteria for award of financial aid prescribed by the Institution.Chief Minister KP ScholarshipTotal seats 20, Tuition fee will be covered only.Detail Criteria:Must be domiciled in a district of the Khyber Pakhtunkhwa provinceThe annual take-home salary in case of salaried person or electricity bill in case of non-salaried person should not exceed Rs. 600,000/- (Rupees six hundred thousand only per annum) and Rs. 50,000/- (Rupees fifty thousand only per annum), respectively."""


# In[41]:


document_visual = nlp(visual)


# In[42]:


#For the nouns in the first webpage
for token in document_visual:
    if token.pos_ == "NOUN":
        print(token, token.pos_)


# In[43]:


#For the verbs in the first webpage
for token in document_visual:
    if token.pos_ == "VERB":
        print(token, token.pos_)


# In[44]:


#For the adjs in the first webpage
adjs = []
for token in document_visual:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[45]:


adjs


# In[46]:


#The second webpage:


# In[47]:


visual2 = """Admission Test for Engineering, Artificial Intelligence and Computer Science Programs
The admission to the Bachelor Programs  of the Institute is decided on the basis of candidate’s earlier educational achievements and his/her score in the admission test, which comprises multiple choice questions based on Pakistani intermediate level Physics and Mathematics and English. The Syllabus of Admission Test and a sample of such questions can be downloaded here.   Syllabus –  Sample Paper.

The test is held simultaneously at Rawalpindi, Islamabad, Peshawar, Lahore, Quetta, Karachi and Multan. The venue and general instructions for the test are intimated on Institute website. Applicants can choose the test center according to their convenience. The results of the admission test are communicated to the selected candidates online through admission website.

For the candidates applying on the basis of SAT-II, the merit will be determined by their Percentile score.

A former student of the Institute whose enrolment was cancelled due to unsatisfactory academic performance is also allowed to appear in the admission test. If selected, he/she will be enrolled in the first semester as a freshman and may not be given credit for the courses passed earlier. Any student who is currently on the roll of the Institute and wants to change the faculty is allowed to appear in the admission test. If selected he/she will not be given credits for the courses passed earlier.

Admission Test for Management Sciences Program
The GIK Common Admissions Test (GCAT) will be taken for admission in BS Management Sciences at test centers. The GCAT will measure reading, writing, and mathematical skills with the objective to assess a candidate’s suitability for undergraduate study. Questions are designed to explore knowledge and skills acquired over a period of time, in order to compare candidates from different academic backgrounds.

Admission Test Syllabus For Management Sciences

Sample Paper For Management Sciences

Acceptance of SAT II
The applicants have the option to take Scholastic Aptitude Test (SAT-II) in Physics and Mathematics (Math IIC) in place of Institute’s Admission test. Applicants have to choose only one basis for their admission i.e. GIK Institute admission test or SAT-II, an option once exercised cannot be changed. The candidates filing two separate applications on two different bases for admission are liable to be disqualified.

An applicant for transfer from a local or foreign institution is required to have passed the Institute’s admission test or SAT – II  respectively by securing equal or more marks than the minimum merit of the faculty in which he/she seeks admission. However, acceptance of request for transfer will depend on availability of seats, and the quality of academic work already done by the applicant.

To send your SAT-II Score, use GIK Institute’s registered Institute Code: 0096

Advanced Standing Admissions
A person who has been enrolled for a relevant Bachelor degree program in engineering at some accredited (PEC, HEC) institution and has earned 15 or more transferable credits with minimum CGPA of 2.5 on the scale of 4, may apply to this Institute for admission with advance standing. However, the student at the GIK Institute wishing to qualify for a bachelor degree must earn a minimum of 70 credits including 6 credits of senior design project. An applicant for transfer from a local or foreign institution is required to have passed the Institute’s admission test or SAT-II  respectively by securing equal to or more marks than the minimum merit of the faculty in which he/she seeks admission. Acceptance of request for transfer will depend on availability of seat, and the quality of academic work already done by the applicant. For supplementary information and application form please contact the Admission Office.

Application Procedure
Click here to apply online.
Login, fill in and submit online application form.
Upload recent color photograph. (Blue Background)
Optionally apply online for scholarship or loan.
Candidates can apply online for Punjab Educational Endowment Fund (PEEF) , Chief Minister Khyber Pakhtunkhwa,  FATA scholarships and  Financial Assistance (Interest Free Loan). Remaining scholarships can be applied for after joining the Institute.

Continuation of scholarships is dependent on satisfactory academic performance of the concerned student and the policies of the donor agencies.

Print Bank Challan. (Processing Fee: Rs. 5500 for single test and Rs. 6500 for both tests, add Rs. 500 if applying for Financial Assistance)
Make payment in Bank and Fill in paid bank challan details in your profile.
Reach test center with Admit Card , orignal Matric/O-Level Certificate and Paid challan GIK Copy on the date and time priinted on your Admit Card.
Check entry test result online.
Send check listed documents to admission office in case of admission is offered.
Keep visiting your profile for any update before and after Entry Test.
How to pay the Application Processing fee ?
Processing fee can be paid Online:

Account Title: GIK Institute HBL A/C No.  00427991707703 for payment in Pak Rupees (PKR).

IBAN #:  PK  70 HABB 0019   7900 0008   5901

OR

For Payment in US $:

IBAN / Account Number :  PK  70 HABB 0019   7900 0008   5901
Name on the Bank Account:  G.I.K Institute Topi
Beneficiary Address:  G.I.K Institute of Engineering Sciences and Technology Topi
Swift Code:  HABB  PKK  AXXX
Bank Name:  Habib Bank Limited GIKI Topi
Bank Address. Habib Bank Ltd G.I.K Institute Branch  (1979), Topi District Swabi KPK Pakistan
 

Eligibility and Assessment Criteria
Basic Eligibility for BS Engineering Programs:

Candidates for admission must meet one of the following criteria:

1.          HSSC (Pre-Engineering i.e Mathematics, Physics and Chemistry) with 60% or above marks each in Mathematics, Physics & Overall.

2.          HSSC (Pre-Medical) with Additional Mathematics and 60% or above marks each in Mathematics, Physics & Overall.

3.          A-Level in three subjects Mathematics, Physics and Chemistry with D or above grade each in Mathematics & Physics and O-Level in eight subjects (English, Mathematics, Physics, Chemistry, Biology/Computer Science, Urdu, Islamic Studies & Pakistan Studies) for local applicants and in five subjects (English, Mathematics, Physics, Chemistry, Biology/Computer Science) for those applying from abroad.

4.          American or Canadian High School Diploma or International Baccalaureate Diploma with Mathematics (with Calculus), Physics and Chemistry with 60% or above marks, as per IBCC equivalence formula, each in Mathematics, Physics & Overall.

5.          Three years Diploma of Associate Engineering (DAE) in relevant technology from a Pakistani Board of Technical Education with at least 60% marks each in Mathematics, Physics & Overall.

Note: Applicant with Mathematics, Physics and Chemistry background can apply for all Programs including Computer Engineering. 

 

Basic Eligibility Criteria for Artificial Intelligence and Computer Science Programs for Admissions 

Candidates for admission must meet one of the following criteria:

HSSC with Mathematics, Physics and any other subject as third elective with 60% or above marks each in Mathematics, Physics & Overall.
A-Level in three subjects Mathematics, Physics and any other subject, with D or above grade each in Mathematics & Physics and O-Level in eight subjects (English, Mathematics, Physics, Chemistry, Biology/Computer Science, Urdu, Islamic Studies & Pakistan Studies) for local applicants and in five subjects (English, Mathematics, Physics, Chemistry, Biology/Computer Science) for those applying from abroad.
Basic Eligibility for BS Management Sciences Program

   Basic Eligibility Criteria: Candidates for admission must meet one of Following Criteria:

1.          HSSC (Pre-Engg), HSSC (General Science), HSSC (ICS), HSSC (Pre-Medical), HSSC (Humanities) with at least 60% overall marks.

2.          A-Level in three subjects with Ds or above grades in two principal subjects and O-Level in eight subjects for local applicants and in five subjects for those applying from abroad with overall 60% or above equivalence as per IBCC formula.

3.          American or Canadian High School Diploma or International Baccalaureate Diploma with overall 60% or above marks, as per IBCC equivalence formula.

Comparative Assessment Criteria (Merit List)

Criteria and Weightage:

Score in Admission Test OR SAT-II (in Mathematics and Physics for Engineering, Artificial Intelligence and Computer Science Programs and in any two subjects for Management Sciences Program.

85%

SSC/O-level (for Those with A-level and O-level background) / Equivalent

15%

Last completed qualification for High School diploma, IB diploma or B.Sc. or DAE

15%

 

 Candidates, who have completed one of the above qualifications and are awaiting results, may apply for provisional admission. Confirmation of admission will, however, be  subject to submission of results by the date specified in the offer letter and fulfilment of the above criteria."""


# In[48]:


document_visual2 = nlp(visual2)


# In[49]:


#For the nouns in the second webpage
for token in document_visual2:
    if token.pos_ == "NOUN":
        print(token, token.pos_)


# In[50]:


#For the verbs in the second webpage
for token in document_visual2:
    if token.pos_ == "VERB":
        print(token, token.pos_)


# In[51]:


#For the adjs in the second webpage
adjs = []
for token in document_visual2:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[52]:


adjs


# In[53]:


#The third webpage:


# In[54]:


visual3 = """Rector CUI
Prof. Dr. Muhammad T. Afzal
Message by the Rector
I feel honored to lead the COMSATS University Islamabad (CUI) as Rector and share with you my vision for CUI, which has always been an innovative institution of learning and development. Our focus in the coming years will be to transform CUI to meet the challenges of a rapidly changing technological environment as well as societal needs through the best affordable academic programs at par with leading global standards, within Pakistan. In short, we envision making CUI "the University of Choice" in Pakistan and across Asia. Although an ambitious vision, but I believe that the talent, skill and experience available at CUI will enable us to achieve success with dedication and hard work.

In the years to come, we will extend out-reach of CUI by adding new campuses capable of catering to the high-quality education needs of a larger canvas of aspiring students and researchers. In this regard, we will also encourage public-private partnerships which will pave the way forward and yield impactful results.

We are committed to making all out efforts to play our due role in minimizing the adverse effects of the global Coronavirus pandemic and bring to the forefront new technologies and pedagogies to achieve our goals.

I would like to assure the parents of our students that CUI will take all possible steps to ensure the safety and well being of your children enrolled at our campuses. We are also deeply committed to inculcate in our graduates the essential skills and professional talent that helps them to meet the needs of the fourth industrial revolution as well as impart industry and market relevant education.

I invite you to explore our website and visit our campuses and interact with our students and faculty members, to find out what distinguishes CUI from other leading universities. I am sure you will be overwhelmed by the achievements, faculty and infrastructure of CUI and give us your valuable feedback which will help us build true professionals and global leaders in thinking.

In conclusion, please join us on our exciting journey into realizing your highest potential; becoming academic leaders in Pakistan and Asia and helping our beloved country by providing impetus to the biggest driver of growth i.e. human resource development.

I pray to Almighty Allah for assistance in our future endeavours and look forward to glorious achievements in the times to come.

Prof. Dr. Muhammad T. Afzal
Rector

About The Rector
Prof. Dr. Muhammad Tabassum Afzal
Prof. Dr. Muhammad Tabassum Afzal has rendered more than 25 years of meritorious services as teacher, researcher and academic leader in institutions of higher learning abroad in Canada and Japan.

During a long illustrious career, Prof. Afzal held several academic and administrative positions and contributed substantially towards the advancement of University research as well as elevating the standards of quality education.

Prof. Afzal is a reputed scientist, internationally recognised for insightful leadership and applied research. He has played a key role in developing a state-of-the-art bioenergy and bioproducts research lab in Canada as well as in the design of several innovative microwave heated reactors in collaboration with his research team.

Prof. Afzal's research is focused on thermo-chemical conversion and design and development of novel technologies to produce renewable fuels, chemicals and value-added products and materials. His research interests are primarily in sustainable process modelling and process optimization for applications in automotive, food, chemical, health and pharmaceutical industry.

In Canada, Prof. Afzal has won highly prestigious peer reviewed natural sciences research grants both individually and in collaboration with other scientists. He has executed several contracts in collaboration with the industry and his research has been translated with consistent publications in highly reputable peer-reviewed international journals having a solid record of accomplishment.

Prof. Afzal is an active scholar with international exposure, having visited and presented his work in 20 countries across North America and Europe. He is also a technical reviewer of several granting agencies and over 20 reputable international research journals.

Prof. Afzal is highly motivated to helping students, faculty and staff excel and contribute to the society not only as professionals but also engage as responsible citizens in the cultural context of Pakistan and deliver excellence in higher education and industry driven research.

He is currently serving as Rector of COMSATS University Islamabad, a leading world ranked public sector university of the Ministry of Science and Technology, Government of Pakistan.

Rector's Office
Rector Office Functions
By virtue of the COMSATS University Islamabad Act 2018, the Rector is the Chief Executive Officer of the University and is responsible for all the administrative and academic functions of the University and for ensuring that the provisions of the Act, Statutes, Regulations and Rules are faithfully observed in order to promote the general efficiency and good order of the university. The Rector has all the powers prescribed for this purpose, including administrative control over the officers, teachers and other employees of the University. The Rector is entitled to attend any meeting of any authority or body of the University.


PROF. DR. MUHAMMAD TABASSUM AFZAL
Rector

rector@comsats.edu.pk

Tel: +92-51-924-7005
Fax: +92-51-924-7006

  

NAVEED A. KHAN
Additional Registrar

naveed@comsats.edu.pk

Tel: +92-51-90495200
Fax: +92-51-924-7006

  

ABDUL MAJID QURESHI
Staff Officer

abdulmajid@comsats.edu.pk

Tel: +92-51-9049-5273
Fax: +92-51-924-5200

  

AZMAT ALI
Personal Secretary to the Rector

azmatali@comsats.edu.pk

Tel: +92-51-924-7005
Tel: +92-51-444-2520
Fax: +92-51-924-7006

  
The Rector can direct teachers, officers and other employees of the Institute to take up such assignments in connection with teaching, research examination, administration and such other activities in the institute, as he may consider necessary for the purposes of the institute.
The Rector can sanction budgeted amounts for the specified purposes.
The Rector can re-appropriate budgetary amounts for unforeseen items not provided for in the budget.
The Rector can make appointments of such categories of employees of the Institute and in such manner as may be prescribed by Statutes.
The Rector can suspend, punish and remove, in accordance with prescribed procedure, from service officers, teachers and other employees of the Institute.
The Rector can delegate, subject to such conditions as may be prescribed, any of his powers to an officer or officers of the Institute.
The Rector can exercise and perform such other powers and functions, as may be prescribed including powers and functions incidental or ancillary to the powers and functions specified here."""


# In[55]:


document_visual3 = nlp(visual3)


# In[56]:


#For the nouns in the third webpage
for token in document_visual3:
    if token.pos_ == "NOUN":
        print(token, token.pos_)


# In[57]:


#For the verbs in the third webpage
for token in document_visual3:
    if token.pos_ == "VERB":
        print(token, token.pos_)


# In[58]:


#For the adjs in the third webpage
adjs = []
for token in document_visual3:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[59]:


adjs


# In[60]:


#For the adjs in the third webpage
adjs = []
for token in document_visual3:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[61]:


adjs


# In[62]:


#The fouth webpage:


# In[63]:


visual4 = """CUI’s History
Historical Perspective
The Commission on Science and Technology for Sustainable Development in the South (COMSATS) is an international organization. It aims to reduce the ever-growing gap between the developed and developing world through useful applications of science and technology. The Third World Academy of Sciences (TWAS) initiated the proposal for the formation of COMSATS under the leadership of Nobel Laureate, Dr. Abdus Salam.

The foundation-conference of COMSATS was held at Islamabad on 4th & 5th October 1994. Representatives from thirty-six countries attended. The participants included twenty-two Ministers, members of the diplomatic community of Islamabad and representatives of international organizations, like UNESCO, UNIDO, UNEP and the World Bank.

The conference decided that the Headquarters / Secretariat of the Commission would be based permanently at Islamabad, Pakistan, and the Head of State of Pakistan would act as the first Chairperson of the forum. It was agreed that the host -Government, Pakistan, would provide for the operational and administrative expenses of the Secretariat, while the development programs of the Commission would be supported and financed through Technical Assistance Fund. This fund would be established by contribution from member countries, income from services provided to member countries, grants from international agencies and project funds, if under taken under contract.

The COMSATS University Islamabad (CUI) was established in 1998, as COMSATS Institute of Information Technology (CII), as a project of the Commission on Science and Technology for Sustainable Development in the South (COMSATS), which is an inter-governmental organization with 27 member states in three continents; Asia, Africa and Latin America, namely Bangladesh, China, Colombia, Egypt, Ghana, Iran, Jamaica, Jordan, Kazakhstan, Korea, Morocco, Nigeria, Pakistan, Palestine, Philippines, Senegal, Somalia, Sri Lanka, Sudan, Syria, Tanzania, Tunisia, Uganda, Yemen and Zimbabwe. Then, CIIT had the status of a public sector degree awarding higher education institution and was given charter by the Federal Government in August 2000. Later, CIIT has been upgraded to a Federally Chartered University in April 2018 under the COMSATS University Islamabad Act 2018.

The CUI functions under the governance of the Senate which is chaired by the Chancellor of the university. The President of Islamic Republic of Pakistan is the Chancellor of the University. Besides, Islamabad it has campuses in Lahore, Abbottabad, Wah, Attock, Sahiwal, Vehari and a Virtual campus as well.

Established/Charter
1998/August 2000

University Charter
April 2018

Vision
CUI aspires to be both one of the top research institutions and one of the best higher education providers in the country. It envisages becoming a university by the name of “COMSATS University”, for which the legal documentation is under process with the Government of Pakistan. The vision being pursued by the CUI is to become one of the top 100 universities in the developing world. The CUI further intends to earn a place among the top 500 universities of the world by the year 2020.

Mission
The Institute's mission is threefold:

i) Research and Discovery
Generate and preserve knowledge, understanding and creativity by instigating enquiry, conducting high-quality research and promoting scholarship, that benefit students, scholars and communities across the country, the Muslim Ummah and the World, at large.

ii) Teaching and Learning
Share the knowledge, understanding and creativity by providing a broad range of educational programs among a diverse community of learners and teachers and prepare graduate, professional and undergraduate students as well as non-degree seeking students interested in continuing education and lifelong learning for active roles in competitive and culturally diverse environments.

iii) Outreach and Public Service
Extend, apply and exchange knowledge between the institute and society by applying scholarly expertise to intellectual, social and technological problems, by helping organizations and individuals respond to their changing environments, and by making the knowledge and resources created and preserved at the institute accessible to the citizens. Using the resources of its multiple campuses in an integrated fashion, the Institute vies to strengthen the services to the state through the education of a modern work force, research and development, technology commercialization and partnership with business, government and community groups

Quick Facts about CUI
 Campuses

 07 physical Campuses

 Faculties

 06

 Academic Programs

 101

 Academic Departments

 22

 Research Centers

 08

 Graduates

 82,000+ including 501+ PhDs

 Total Library Books

 195,000+

 Faculty

 2,300+

 Distinction

 1,100+ PhD Faculty and Academic Managers

 Students

 34,216 as of Spring 2021

 International Students

 435 students from 24 countries

 Research Publications

 17000+

 Patents

 Filed 90, Granted 38

 Licensed Technologies

 03

International Linkages
CUI is vigorously involved in sharing expertise and knowledge from all over the world, with the aim of introducing latest developments in research and best practices within the present education environment.

Further details of CUI’s foreign collaborations with countries located in diferent regions of the world (Asia, Europe, Africa/Middle East, Americas (USA/Canada), and Austraila/ Newzealand) is given on the link http://ww3.comsats.edu.pk/internationaloffice/intlink.aspx

Why CUI
The origins of the COMSATS University Islamabad (CUI) date back to 1998. The university is one of the leading universities of Pakistan with five (05) broad faculties including Engineering, Information Science and Technology, Business Administration and Architecture and Design with more than 36,000 students and offering 100-degree programs. The CUI is well-known for its trend-setting pedagogical approach, allowing for interdisciplinary methodologies to learning and problem solving, experimentation, and insight. It is ranked among top 3 universities of Pakistan and world’s best 800 universities. In addition, CUI has also developed state of the art Business Incubation Center to promote the entrepreneurial culture to cater the respectable employment opportunities for our educated and technical manpower and development of indigenous enterprises. For details, please visit the link http://ww3.comsats.edu.pk/bic/
"""


# In[64]:


document_visual4 = nlp(visual4)


# In[65]:


#For the nouns in the fourth webpage
for token in document_visual4:
    if token.pos_ == "NOUN":
        print(token, token.pos_)


# In[66]:


#For the verbs in the third webpage
for token in document_visual4:
    if token.pos_ == "VERB":
        print(token, token.pos_)


# In[67]:


#For the adjs in the fourth webpage
adjs = []
for token in document_visual4:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[68]:


adjs


# In[69]:


#The fiveth webpage:


# In[70]:


visual5 = """Research & Innovation Offices, established to promote culture of entrepreneurship and research at NUST – an SDG engaged University that has aligned its core functions with the UN SGDs.

The role of Universities is fast changing in this world that is driven by technological innovation; universities are increasingly becoming the epicentre of knowledge creation, a trait of being a third generation university, to propel this technological innovation. This created knowledge has to be then successfully transferred to the society to make an impact and contribute towards knowledge economy.  This complete process from ideation to knowledge transfer and creating impact, that follows a non-linear model and is thus a challenge in itself, is managed by NUST R&I offices. Together these offices promote the spirit of technological innovation by bringing in ideas from the industry, support various research activities as well as conferences and workshops, offer intellectual property related services, foster innovative and creation of start-up enterprises as well as spin off companies and facilitating through TechOne Incubator (https://techOne.pk??) and National Science and technology Park (https://nstp.pk), maintain industrial linkages for knowledge transfer by developing market collaterals of the innovations – indeed a system of systems that are so well – gelled at NUST and accruing results.

Owing to our ever growing and multifarious industry linkages, R&I offices also include the NUST Placement office, to offer our core product i.e., our graduates to the industry.  We focus on personal grooming and soft skill development of our graduates to well-prepare them for the ‘life – ahead’ and enhance their employability prospects.  The success of this complete eco-system of making them ‘market-ready’ has been so well acknowledged by QS Rankings which has placed NUST at 148 internationally (and Pakistan’s no 1) in its employability survey of 2020.

The colourful spectrum of R&I offices also includes the University Advancement and Alumni offices – to pursue endowment raisings, fund raisings for University expansion projects as well as for the financially challenged students, and support the Alumni affairs. We have a vibrant NUST Alumni Network representing a family that is continuously growing and adding new members. NUST always invites its alumni to get engaged with their alma mater by seeking their participation in different academic initiatives.

The entire team of R&I is there to offer its best services to its clients – be they internal to the University or those who are outside, in meeting the University objectives.  The R&I team has been instrumental in making tangible contribution and so would it continue in the future with much more vigour to deliver what NUST is obligated to deliver to the society.

NUST appreciates the great contribution which our industry and alumni partners are making towards NUST journey of making impact.  Our success story would not have been possible without them in promoting innovation, technology transfer, employing NUSTians, delivering innovation and industrial talk series, endowments etc to name a few.  We look forward to their intimate support and advancing together in the future.

(Air Vice Marshal Dr Rizwan Riaz SI(M)""" 


# In[71]:


document_visual5 = nlp(visual5)


# In[72]:


#For the nouns in the fiveth webpage
for token in document_visual5:
    if token.pos_ == "NOUN":
        print(token, token.pos_)


# In[73]:


#For the verbs in the fiveth webpage
for token in document_visual5:
    if token.pos_ == "VERB":
        print(token, token.pos_)


# In[74]:


#For the adjs in the fiveth webpage
adjs = []
for token in document_visual5:
    if token.pos_ == 'ADJ':
        adjs.append(token.text)


# In[75]:


adjs


# In[76]:


adjs_tally = Counter(adjs)


# In[77]:


adjs_tally.most_common()


# In[78]:


df = pd.DataFrame(adjs_tally.most_common(), columns=['adj', 'count'])
df[:100]


# In[83]:


nouns = []
for token in document_visual:
    if token.pos_ == 'NOUN':
        nouns.append(token.text)

nouns_tally = Counter(nouns)

df = pd.DataFrame(nouns_tally.most_common(), columns=['noun', 'count'])
df[:100]


# In[79]:


nouns = []
for token in document_visual2:
    if token.pos_ == 'NOUN':
        nouns.append(token.text)

nouns_tally = Counter(nouns)

df = pd.DataFrame(nouns_tally.most_common(), columns=['noun', 'count'])
df[:100]


# In[80]:


nouns = []
for token in document_visual3:
    if token.pos_ == 'NOUN':
        nouns.append(token.text)

nouns_tally = Counter(nouns)

df = pd.DataFrame(nouns_tally.most_common(), columns=['noun', 'count'])
df[:100]


# In[81]:


nouns = []
for token in document_visual4:
    if token.pos_ == 'NOUN':
        nouns.append(token.text)

nouns_tally = Counter(nouns)

df = pd.DataFrame(nouns_tally.most_common(), columns=['noun', 'count'])
df[:100]


# In[82]:


nouns = []
for token in document_visual5:
    if token.pos_ == 'NOUN':
        nouns.append(token.text)

nouns_tally = Counter(nouns)

df = pd.DataFrame(nouns_tally.most_common(), columns=['noun', 'count'])
df[:100]


# In[83]:


verbs = [token.text for token in document_visual if token.pos_ == 'VERB']

verbs_tally = Counter(verbs)

df = pd.DataFrame(verbs_tally.most_common(), columns=['verb', 'count'])
df[:100]


# In[84]:


verbs = [token.text for token in document_visual2 if token.pos_ == 'VERB']

verbs_tally = Counter(verbs)

df = pd.DataFrame(verbs_tally.most_common(), columns=['verb', 'count'])
df[:100]


# In[85]:


verbs = [token.text for token in document_visual3 if token.pos_ == 'VERB']

verbs_tally = Counter(verbs)

df = pd.DataFrame(verbs_tally.most_common(), columns=['verb', 'count'])
df[:100]


# In[86]:


verbs = [token.text for token in document_visual4 if token.pos_ == 'VERB']

verbs_tally = Counter(verbs)

df = pd.DataFrame(verbs_tally.most_common(), columns=['verb', 'count'])
df[:100]


# In[87]:


verbs = [token.text for token in document_visual5 if token.pos_ == 'VERB']

verbs_tally = Counter(verbs)

df = pd.DataFrame(verbs_tally.most_common(), columns=['verb', 'count'])
df[:100]


# In[88]:


#The first webpage visual
options = {"compact": True, "distance": 90, "color": "yellow", "bg": "black", "font": "Gill Sans"}

displacy.render(document_visual, style="dep", options=options)


# In[94]:


#The second webpage visual
options = {"compact": True, "distance": 90, "color": "yellow", "bg": "black", "font": "Gill Sans"}

displacy.render(document_visual2, style="dep", options=options)


# In[89]:


#The third webpage visual
options = {"compact": True, "distance": 90, "color": "yellow", "bg": "black", "font": "Gill Sans"}

displacy.render(document_visual3, style="dep", options=options)


# In[91]:


#The fourth webpage visual
options = {"compact": True, "distance": 90, "color": "yellow", "bg": "black", "font": "Gill Sans"}

displacy.render(document_visual4, style="dep", options=options)


# In[92]:


#The fiveth webpage visual
options = {"compact": True, "distance": 90, "color": "yellow", "bg": "black", "font": "Gill Sans"}

displacy.render(document_visual5, style="dep", options=options)


# In[98]:


#The third part of the project:


# In[235]:


#!pip install networkx


# In[ ]:




