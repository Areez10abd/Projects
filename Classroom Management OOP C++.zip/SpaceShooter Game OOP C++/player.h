//Areez Abdullah 22i-1090 CS-D OOP Project
#include <SFML/Graphics.hpp>
#include<cmath>
#include<string.h>
#include<iostream>
#include"Bullet.h"
using namespace sf;


//class for player which is inherited from bullet
class Player : public Bullet
{
	public:


	//variable for the png
	int a;
	Sprite sprite;
	Texture texture;
	//angle for moving player right and left
	float for_angle;
	//speed for the player
	float speed=1;
	//Axis for x and y
	int for_x,for_y;
	//object for bullet
	Bullet *obj_b;

	

	Player(std::string png_path)
	{
		
		//Timer
		a=100;
		texture.loadFromFile(png_path);
		sprite.setTexture(texture);
		//x and y axis for it
		for_x=340;
		for_y=680;
		//position for it
		sprite.setPosition(for_x,for_y);
		//setting scale for the buller
		sprite.setScale(0.75,0.75);
		//this is the picture of the bullet
		obj_b=new Bullet("img/PNG/Lasers/laserGreen06.png");

	}


	
	void fireBullet()
	{
		//For movement of player and bullet with respect to y and x axis
		obj_b->x_axis=getX();
		obj_b->y_axis=getY();
		//position of the bullet according to the ship
		obj_b->sprite.setPosition(30+getX(),getY()-15);
	
	}


	void move(std::string s)
	{	
			float x_angle=0;
			float y_angle=0;
			
			//this statment moves the player to the right
			if(s=="r")
			{
				x_angle=1;
				//this is for moving the ship diagonal when moving right
				for_angle=0.75f;
				sprite.setRotation(180*for_angle/M_PI);
			}
			
			//this statment moves the player to the left
			else if(s=="l")
			{
				x_angle=-1;
				//this is for moving the ship diagonal when moving left
				for_angle=-0.75f;
				sprite.setRotation(180*for_angle/M_PI); 
			}

			
			else
			{
				//no movement left and rigth
				for_angle=0.f;
				sprite.setRotation(0); 	
			}
			
			//moving up
			if(s=="u")
				{y_angle=-1;}

			//moving down
			else if(s=="d")
				{y_angle=1;}
		
			//moving diagonally right
			else if(s=="s")
			{
				y_angle=-1; 
				x_angle=1;
				//diagonal angle
				for_angle=0.75f;
				sprite.setRotation(180*for_angle/ M_PI);
				
			}
			
			//moving diagonally left		
			else if(s=="a")
			{
				x_angle=-1;
				y_angle=-1;
				//diagonal angle
				for_angle=-0.75f;
				sprite.setRotation(180*for_angle/M_PI); 
			}
		
			else if(s=="d")
			{
				for_angle=0.f;
				sprite.setRotation(0); 	
			}
		
			//multiplying the x axis ad y axis of it with speed
			x_angle=speed*x_angle;
			y_angle=speed*y_angle;
			//calling the movment
			sprite.move(x_angle, y_angle);
	
	}
	
	void movement_1(int x)
	{sprite.move(x,0);}
	
	
	void movement_2(int y)
	{sprite.move(0,y);}
	
	//getters
	int getX()
	{return sprite.getPosition().x;}
	int getY()
	{return sprite.getPosition().y;}
	
	const sf::FloatRect getBounds() const
	{return sprite.getGlobalBounds();}
	
	//function for rotation
	void rotation(Sprite& sprite, float theta)
	{
		//theta=pi*theta divide by 180 degrees
		theta=(3.14*theta/180);
		
		//this is for cosine
		float cos_theta=cos(theta);
		
		//this is for sine
    		float sin_theta= sin(theta);
    		
    		//roation trow matrix
    		float rotation_matrix[2][2]= 
    		{
    			//+cos and -sin
        		{cos_theta,-sin_theta},
        		//+sin and +cos
        		{sin_theta,cos_theta}
		};
					 
					    
		float x=sprite.getPosition().x;
    		float y=sprite.getPosition().y;

    		//This is for rotating the position of the sprite
    		float x_2=rotation_matrix[0][0]*x+rotation_matrix[0][1]*y;
    		float y_2=rotation_matrix[1][0]*x+rotation_matrix[1][1]*y;

    		//creating new position of the sprite
    		sprite.setPosition(x_2,y_2);   
	}

	sf::FloatRect getGlobalBounds() const 
	{return sprite.getGlobalBounds();}
	
};
