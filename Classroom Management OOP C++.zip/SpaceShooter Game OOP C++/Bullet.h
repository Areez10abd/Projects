//Areez Abdullah 22i-1090 CS-D OOP Project
#include <SFML/Graphics.hpp>
using namespace sf;

class Bullet
{
	public:
	Sprite sprite;
	Texture texture;
	//damage for a bullet
	int damage=5;
	int x_axis;
	int y_axis;
	//speed of the bullter	
	float speed=-5;

	//png for bullet
	Bullet(std::string png_path)
	{
		texture.loadFromFile(png_path);
		sprite.setTexture(texture);
	}

	Bullet()
	{
		//Deafault constrctor
	}

	//update the time with speed
	void update(float time)
	{
		sprite.move(0,time*speed);
	}

	sf::FloatRect getGlobalBounds() const 
	{return sprite.getGlobalBounds();}
};
