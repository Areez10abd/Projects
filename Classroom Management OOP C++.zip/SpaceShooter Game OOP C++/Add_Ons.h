//Areez Abdullah 22i-1090 CS-D OOP Project
#include <SFML/Graphics.hpp>

using namespace sf;

//Showing lives at the top
class Lives 
{
	public:
	    //recording lives
	    int lives;
	    sf::Font font;
	    sf::Text texture;
    	    

	     Lives(int live_start, int of_x,int of_y, float size, sf::Color color) 
	     {
	    	//Parameterized constructor
	        lives = live_start;
	        font.loadFromFile("/usr/share/fonts/truetype/abyssinica/AbyssinicaSIL-Regular.ttf");
	        setPosition(of_x,of_y);
		texture.setFont(font);
	   	updateText();
	        texture.setCharacterSize(size);
	        texture.setFillColor(color);
	     }

    	     void setPosition(int of_x,int of_y) 
    	     {
    	     	//setting position
    	        texture.setPosition(of_x,of_y);
    	     }
    
    	     void increase() 
    	     {
        	//live increasing
        	lives=1+lives;
        	//updating texture
        	updateText();
             }

	     void decrease() 
    	     {
    	     	//live decreasing
        	lives=lives-1;
        	//updating texture
        	updateText();
             }
             
    	     int getLives() const 
    	     {
    	    	//getter for lives
    	    	return lives;
    	     }

    	    void draw(sf::RenderWindow& window) const 
    	    {
    	    	//drawing the texture
        	window.draw(texture);
    	    }

    	    void updateText() 
    	    {
    	    	//updating the texture
    	    	texture.setString("Lives left: " + std::to_string(lives));
    	    }
};


class Danger 
{

	//problem 3: danger is shown in the start it should come randomly with gap of 1minute and player should avoid it to get 50score otherwise lose life
	public:

	sf::Sprite m_sprite;
    	sf::Texture texture;
    	float m_speed;
    	int X,Y;
    
	    Danger( )
	    {
	    	//Default constructor
	    }
    
    	    Danger( int of_x, int of_y, double of_speed)
    	    {
    	    	//parameterized constructor
    		texture.loadFromFile("img/PNG/Meteors/meteorBrown_big2.png");
    		m_sprite.setTexture(texture);
    		m_sprite.setPosition(of_x,of_y);
    		m_speed=of_speed;
    	    }
    	
	    //it updates the position
    	    void update(float timer)
    	    {m_sprite.move(0,0.5);}

    	    //danger collison with the player
    	    bool checkCollision(sf::FloatRect playerBounds)
    	    {return m_sprite.getGlobalBounds().intersects(playerBounds);}
    
    	     //drawing the object
    	     void draw(sf::RenderWindow& window);

	     //getters
       	     int getX()
		{return m_sprite.getPosition().x;}

	    int getY()
		{return m_sprite.getPosition().y;}
};






class Live_add
{
public:

	sf::Sprite m_sprite;
    	sf::Texture texture;
    	float for_speed;
    	
	Live_add()
	{
		//Default constructor
	}
	
	Live_add(int for_x, int for_y, double speed) 
	{
	    //Parameterized constructor
	    texture.loadFromFile("img/PNG/Power-ups/powerupGreen_shield.png");
	    m_sprite.setTexture(texture);
	    m_sprite.setPosition(for_x,for_y);
	    for_speed=speed;
	}

	//update position 
	void update(float for_time) 
	{m_sprite.move(0.0f, for_time*for_speed);}

	//it checks if the object has collieded with the spaceship
	bool checkCollision(sf::FloatRect playerBounds) 
	{return m_sprite.getGlobalBounds().intersects(playerBounds);}



};


