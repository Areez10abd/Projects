//Areez Abdullah 22i-1090 CS-D OOP Project
#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>
#include <iostream>
#include <random>

using namespace sf;

//AlphaInvader Enemy
class AlphaInvader
{
	public:
		int a;
		int b;
		Texture texture;
		Sprite sprite;
		int X,Y;

	AlphaInvader(int x,int y)
	{
		//constructor
		X=x;
		Y=y;
		b=10;
		a=b;
		texture.loadFromFile("img/enemy_1.png");
		sprite.setTexture(texture);
		sprite.setPosition(x,y);
		sprite.setScale(0.5,0.5);
	}


sf::FloatRect getGlobalBounds() const {
        return sprite.getGlobalBounds();
    }
    
void draw(sf::RenderWindow& window) const {
        window.draw(sprite);
    }
    
     bool isOfscreen(sf::RenderTarget& target)
    {
        return sprite.getPosition().y < 0 || sprite.getPosition().y >780;
    }
    
    
    int getX()
{return sprite.getPosition().x;}

int getY()
{return sprite.getPosition().y;}
    
};


class Bomb {
public:
    Sprite shape;
    Texture tex;
    float speed=10;


    Bomb(std::string png_path)
{
	tex.loadFromFile(png_path);
	shape.setTexture(tex);
}
	Bomb()
	{}
	
    void update(float dt) {
        shape.move(0,speed * dt);
    }
    bool isOfscreen(sf::RenderTarget& target) {
        return shape.getPosition().y < 0 || shape.getPosition().y > target.getSize().y;
    }

    void draw(sf::RenderWindow& window) const {
        window.draw(shape);
    }
    
    sf::FloatRect getGlobalBounds() {
        return shape.getGlobalBounds();
    }

int gX()
{return shape.getPosition().x;}

int gY()
{return shape.getPosition().y;}

sf::FloatRect getGlobalBounds() const {
        return shape.getGlobalBounds();
    }

};



//BetaInvader Enemy
class BetaInvader:public Bomb {
public:
    Sprite shape;
    Texture tex;
    Bomb *bombs;
    Sprite sprite;


BetaInvader(int x,int y):Bomb()
{
	tex.loadFromFile("img/enemy_2.png");
	shape.setTexture(tex);
	shape.setPosition(x,y);
	shape.setScale(0.4,0.4);
	bombs=new Bomb("img/PNG/Lasers/laserRed09.png");
}

    int gtX()
{return shape.getPosition().x;}

int gtY()
{return shape.getPosition().y;}

void Fire()
{
	bombs->shape.setPosition(gtX()+30,gtY()-15);
}

sf::FloatRect getGlobalBounds() const {
        return shape.getGlobalBounds();
    }
    
    bool isOfscreen(sf::RenderTarget& target)
    {
        return shape.getPosition().y < 0 || shape.getPosition().y > 780;
    }
    void draw(sf::RenderWindow& window) const {
        window.draw(sprite);
    }
};

//GammaInvader Enemy
class GammaInvader:public Bomb {
public:
    Sprite shape;
    Texture tex;
    Bomb *bombs;


GammaInvader(int x,int y):Bomb()
{
	tex.loadFromFile("img/enemy_3.png");
	shape.setTexture(tex);
	shape.setPosition(x,y);
	shape.setScale(0.4,0.4);
	bombs=new Bomb("img/PNG/Lasers/laserGreen16.png");
}

void m()
{
	shape.move(1,0);
}
void n(int n)
{
	shape.move(-n,0);
}
    int gtX()
{return shape.getPosition().x;}

int gtY()
{return shape.getPosition().y;}

void Fire()
{
	bombs->shape.setPosition(gtX()+26,gtY()-15);
}

sf::FloatRect getGlobalBounds() const {
        return shape.getGlobalBounds();
    }
    
    bool isOfscreen(sf::RenderTarget& target)
    {
        return shape.getPosition().y < 0 || shape.getPosition().y > target.getSize().y;
    }
};

//Monster Enemy
class Monster : public Bomb {
public:
    Sprite shape;
    Texture tex;
    Bomb *lightningBeam;
    Clock clock;
    bool isFiring;
    int direction;

    Monster(int x, int y) : Bomb() {
        tex.loadFromFile("img/monster.png");
        shape.setTexture(tex);
        shape.setPosition(x, y);
        shape.setScale(0.25, 0.25);
        lightningBeam = new Bomb("img/PNG/Lasers/laserBlue08.png");
        isFiring = false;
        direction = 1;
    }

    void update(float dt) {
        if (!isFiring && (int)clock.getElapsedTime().asSeconds() % 4 == 0) {
            fire();
            isFiring = true;
        }
	if (isFiring && (int)clock.getElapsedTime().asSeconds() % 6 == 0)
	{
		isFiring = false;	
	}
        if (isFiring) {
            lightningBeam->update(dt);
            
        }

        shape.move(direction * 2, 0);
        if (shape.getPosition().x < 0 || shape.getPosition().x > 780) {
            direction *= -1;
        }
    }

    void fire() {
        lightningBeam->shape.setPosition(shape.getPosition().x + 30, shape.getPosition().y - 15);
    }

    sf::FloatRect getGlobalBounds() const {
        return shape.getGlobalBounds();
    }

    bool isOfscreen(sf::RenderTarget& target) {
        return shape.getPosition().y < 0 || shape.getPosition().y > target.getSize().y;
    }

    void draw(sf::RenderWindow& window) const {
        window.draw(shape);
        if (isFiring) {
            window.draw(lightningBeam->shape);
        }
    }
};


//Dragon Enemy
class Dragon : public Bomb {
public:
    Sprite shape;
    Texture tex;
    Bomb *fire;
    Clock clock;
    Clock appearanceClock;
    bool isVisible;
    float appearanceInterval;
    float visibleDuration;

    Dragon(int x, int y) : Bomb() {
        tex.loadFromFile("img/dragon1.png");
        shape.setTexture(tex);
        shape.setPosition(x, y);
        shape.setScale(2, 2);
        fire = new Bomb("img/PNG/Lasers/laserRed08.png");
        isVisible = false;
        visibleDuration = 5.0f;
        setRandomAppearanceInterval();
    }

    void setRandomAppearanceInterval() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(5.0, 15.0);
        appearanceInterval = dis(gen);
    }

    void update(float dt, float spaceshipX, float spaceshipY) {
        if (!isVisible && appearanceClock.getElapsedTime().asSeconds() >= appearanceInterval) {
            isVisible = true;
            clock.restart();
        }

        if (isVisible) {
            if (clock.getElapsedTime().asSeconds() >= visibleDuration) {
                isVisible = false;
                appearanceClock.restart();
                setRandomAppearanceInterval();
            } else {
                fireBasedOnSpaceshipPosition(spaceshipX, spaceshipY);
                fire->update(dt);
            }
        }
    }

    void fireBasedOnSpaceshipPosition(float spaceshipX, float spaceshipY) {
        float fireDirectionX, fireDirectionY;
        if (spaceshipX < shape.getPosition().x) {
            fireDirectionX = -1;
            fireDirectionY = 1;
        } else if (spaceshipX > shape.getPosition().x + shape.getGlobalBounds().width) {
            fireDirectionX = 1;
            fireDirectionY = 1;
        } else {
            fireDirectionX = 0;
            fireDirectionY = 1;
        }
        fire->shape.setPosition(shape.getPosition().x + shape.getGlobalBounds().width / 2, shape.getPosition().y + shape.getGlobalBounds().height);
        fire->shape.setRotation(atan2f(fireDirectionY, fireDirectionX) * 180 / 3.14159265);
    }

    sf::FloatRect getGlobalBounds() const {
        return shape.getGlobalBounds();
    }

    bool isOfscreen(sf::RenderTarget& target) {
if (shape.getPosition().y < 0 || shape.getPosition().y > target.getSize().y) {
return true;
}
return false;
}
void draw(sf::RenderWindow& window) const 
{
    if (isVisible) 
    {
        window.draw(shape);
        window.draw(fire->shape);
    } 
   else 
   {
    if (isOfscreen(window)) 
    {
          sf::Texture completeTex;
         completeTex.loadFromFile("img/Complete.png");
         sf::Sprite completeSprite(completeTex);
         completeSprite.setPosition(shape.getPosition().x, target.getSize().y - completeSprite.getGlobalBounds().height);    
         window.draw(completeSprite);
     }
   }
  }
  
};


   
