//Areez Abdullah 22i-1090 CS-D OOP Project
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

class StartMenu
{
	public:
	    void display_menu(bool& start, RenderWindow& w)
{
	handleInput(start, w);
	
}
		
    void displayInstructions() 
    {
        cout << "=== Instructions ===" << endl;
       cout << "Press p for pause" <<endl<<"Press S for diagonal right"<<endl<<"A for diagonal left"<<endl<<"D to return back to normal"<<endl<<"Press e to exit"<<endl<<endl;
       
        cout << "The player controls a spaceship in an enemy filled space field. The spaceship can move in all possible directions (right, left, up, down and diagonally)." <<endl<< endl;
        cout << "The spaceship can fire bullets to destroy the objects in the space field." << endl<< endl;
        cout << "The spaceship can also avail the add-ons options which would fall after random intervals." <<endl<<  endl;
        cout << "1. Power Up: The power-up feature will fall randomly in galactic space. Once the player receives the power-up add-on, the spaceship will fire a continuous beam of bullets in all seven directions as shown in figure. It will be time-controlled lasting only for 5 seconds. In the power-up mode, the spaceship will not be destroyed even if the enemy bombs hit the spaceship." << endl<< endl;
        cout << "2. Fire: Another feature that the spaceship can avail is to catch fire. Once the spaceship avails this add-on, its bullets will change into fire destroying all the spaceships in its way. It will also last for 5 seconds only." <<endl<<  endl;
        cout << "3. Danger: Another add-on feature is the danger sign. This danger sign cannot be destroyed by bullets or bombs. The spaceship needs to maneuver in a way as to dodge and avoid collision with the danger sign. If the spaceship comes in contact with the danger sign, it will be destroyed, and the lives would be decreased. The score to dodge the danger sign is 5." <<endl<<  endl;
        cout << "4. Lives: The lives add-on would help the spaceship by incrementing the remaining lives by 1." <<endl<<  endl;
        cout << "" <<endl<<  endl;
    }

    void displayGamePlay() 
    {
        cout << "=== Game Play ===" << endl;
        cout << "Use the arrow keys to move the spaceship, and the spacebar to fire bullets." << endl;
        cout << "Destroy all the enemies to advance to the next level." << endl;
        cout << "Collect power-ups to gain special abilities." << endl;
    }

    void displayPauseScreen() 
    {
        cout << "=== Paused ===" << endl;
        cout << "1. Resume" << endl;
        cout << "2. Quit to Main Menu" << endl;
    }

  
	
    
    void displayHighScores() {
        ifstream file("high_score.txt");
        if (!file.is_open()) {
            cout << "Failed to open file" << endl;
            return;
        }
        cout << "=== High Scores ===" << endl;
	string out;
	file >> out;
	cout << out << endl;
        file.close();
    }

    void displayEndScreen()
    {
        cout << "=== Game Over ===" << endl;
        cout << "Thanks for playing!" << endl;

    }

    void handleInput(bool& start, RenderWindow& window)
    {
        Event e;
        while (window.pollEvent(e))
        {
            if (e.type == Event::Closed)
                window.close();
            else if (e.type == Event::KeyPressed)
            {
                if (e.key.code == Keyboard::Num1)
                    displayInstructions();
                else if (e.key.code == Keyboard::Num2)
                   start = false;
                    else if (e.key.code == Keyboard::Num3)
                    displayHighScores();
                else if (e.key.code == Keyboard::Num4)
                {
     	          
       			 cout << "=== Game Over ===" << endl;
       			 cout << "Thanks for playing!" << endl;
  			window.close();
                }
            }
        }
    }
  

};

