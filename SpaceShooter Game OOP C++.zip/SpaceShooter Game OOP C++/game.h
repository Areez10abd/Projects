//Areez Abdullah 22i-1090 CS-D OOP Project

#include <SFML/Graphics.hpp>
#include<iostream>
#include <time.h>
#include<string>
#include<math.h>
#include"player.h"
#include"Enemy.h"
#include"startmenu.h"
#include"Add_Ons.h"
using namespace sf;


const char title[] = "OOP-Project Space Shooter, Spring-2023";

class Game 
{
	public:
	//for the background 
	Sprite background; 
	//this is for texture for backgroung
	Texture text_background;
	//for the player
	Player* player; 
	//for making lives
	Lives *life;
	//incrementing lives
	Live_add ad;
	//creating a danger
	Danger danger;
	//adding a destructing when something gets destroyed 
	Sprite destroy; 
	//destruction
	Sprite p_destroy;
	//this is for showing damaged AlphaInvadership
	Texture text;
	//this is for menu
	Texture text_1;
	//this is for showing the gameover screen
	Texture text_2;
	//for another ship
	Texture text_3;
	//this is for opening menu
	Sprite smenu;
	//creating a menu
	StartMenu M;
	//sprite for game
	Sprite game;
	//to finish and start the game
	bool start,finish ;
	//checking for time
	int check_time;
	//this is for completing the game 
	Sprite complete;
   	Texture text_complete;

	
	
	
	Game()
	{
		//This is for menu
		text_1.loadFromFile("img/Title.png");
		smenu.setTexture(text_1);
		smenu.setScale(1.95, 1.95);

		//png for player
		player=new Player("img/player_ship.png");

		//loading image for background
		text_background.loadFromFile("img/background.jpg");
		background.setTexture(text_background);
		background.setScale(2.25, 1.95);

		//loading this image when AlphaInvaderis killed
		text.loadFromFile("img/PNG/Damage/playerShip2_damage1.png");
		destroy.setTexture(text);
		destroy.setScale(0.5, 1);
		p_destroy.setScale(0.5, 1);

		//showing life on the screen
		life=new Lives(3,850, 200, 20, sf::Color::Green);
		check_time=0;
		finish=0;
		start=1;	
		background.setScale(2.5, 1.95);
		text_2.loadFromFile("img/GameOver.png");
		game.setTexture(text_2);
		game.setScale(2, 1.8);
		
		
 

	}

void start_game()
{
    //random time
    srand(time(0));
    RenderWindow window(VideoMode(1000,800), title);
    
    Clock clock;
    //this is for time_1
    float time_1;
    //time_taken or time span
    int time_taken=900;
    //this bool to stop when p is pressed for pausing
    bool pausing=false;
    float time_2[14]={2};
    //two counter for time
    int counter_1=0,counter_2=0, counter_3=0;
    bool e_1=1,e_2=0,e_3=0,e_4=0,danger_2=0,e_5=0,e_6=0,e_7=0;
    float dx[15],dy[15],dis[15],delay = 0;
    int score=0,c1=0,Pl=false;


 	
 	Font font;
 	font.loadFromFile("/usr/share/fonts/truetype/abyssinica/AbyssinicaSIL-Regular.ttf");
 	

   
    
    
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(24);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(850, 100);
        
        
   //Level 1:
   
        //First pattern Cross
        AlphaInvader alpha_1[10]=
        {
	  AlphaInvader(300,-200),
	  AlphaInvader(400,-100),
	  AlphaInvader(500,0),
	  AlphaInvader(600,100),
	  AlphaInvader(700,200),
          AlphaInvader(300,200),
          AlphaInvader(400,100),
          AlphaInvader(500,0),
          AlphaInvader(600,-100),
          AlphaInvader(700,-200),
        };
        
        //Second pattern Rectangle
        AlphaInvader alpha_2[10]=
        { 
        	AlphaInvader(300,-200),
        	AlphaInvader(400,-200),
        	AlphaInvader(500,-200),
        	AlphaInvader(600,-200),
        	AlphaInvader(300,-100), 								
        	AlphaInvader(600,-100),
        	AlphaInvader(300,0),
        	AlphaInvader(400,0),
               	AlphaInvader(500,0),
		AlphaInvader(600,0),   
      
        };
        
        //Third pattern Circle
        
        AlphaInvader alpha_3[10]=
        { 
    	  	AlphaInvader(500,-250),
    	  	AlphaInvader(450,-200),
    		AlphaInvader(400,-150),
    		AlphaInvader(400,-100),
    		AlphaInvader(450,-50),
    		AlphaInvader(500,0),
    		AlphaInvader(550,-50),
    		AlphaInvader(600,-100),
    		AlphaInvader(600,-150),
    		AlphaInvader(550,-200), 
        };
        
        
        AlphaInvader a1(0,300),a2(780,300);
        
       //level 2
       
        //first pattern filled triangle
        BetaInvader beta_1[14]= 	
        {
        	BetaInvader(100,100),
        	BetaInvader(200,100),
        	BetaInvader(300,100),
        	BetaInvader(400,100),
        	BetaInvader(500,100),
        	BetaInvader(600,100),
        	BetaInvader(200,200),
        	BetaInvader(300,200),
        	BetaInvader(400,200),
        	BetaInvader(500,200),
        	BetaInvader(250,300),
        	BetaInvader(350,300),
        	BetaInvader(450,300),
        	BetaInvader(350,400)
        };
        //second pattern filled rectangle
        
        BetaInvader beta_2[14]= 	
        {
        	BetaInvader(200,100),
        	BetaInvader(300,100),
        	BetaInvader(400,100),
        	BetaInvader(500,100),
        	BetaInvader(200,200),
        	BetaInvader(300,200),
        	BetaInvader(400,200),
        	BetaInvader(500,200),
        	BetaInvader(200,300),
        	BetaInvader(300,300),
        	BetaInvader(400,300),
        	BetaInvader(500,300),
        	BetaInvader(500,300),
        	BetaInvader(500,300)
        };

        	
       
        //Pattern heart	
        GammaInvader gamma[14]=
        {
        	GammaInvader(400,100),
        	GammaInvader(375,50),
        	GammaInvader(350,0),
        	GammaInvader(250,50),
        	GammaInvader(300,100),
        	GammaInvader(350,200),
        	GammaInvader(375,275),
        	GammaInvader(400,350),
        	GammaInvader(425,275),
        	GammaInvader(450,200),
        	GammaInvader(500,100),
        	GammaInvader(550,50),
        	GammaInvader(450,0),
        	GammaInvader(425,50),
        };
    //level 3    
    	Monster mons(300, 0);
        Dragon drag(200, 0);
       		
        
       Danger danger(100 + rand()%700,0,3);
       Live_add ad(rand()%700,rand()%700,3);
	
	while (window.isOpen())
    	{
    		if (start==true)
    		{

    			window.draw(smenu);
    			window.display();
    			M.display_menu(start, window);
    	
    		}
    		else
    		{

    			if (finish==false)
    		{
        		float time = clock.getElapsedTime().asSeconds(); 
        		if(pausing==false)
        		time_1 += time;   
 	Event e;
 	bool rotation_a,rotation_b;
 	
 	
 	float elapsedTime=clock.getElapsedTime().asSeconds();
 	int counter_2=0;
 	check_time+=elapsedTime;
 	
 	
 	if(ad.checkCollision(player->getGlobalBounds()))
			{
				life->increase();
				ad.m_sprite.setPosition(rand()%700,rand()%700);	
			}
 
 	if(danger.checkCollision(player->getGlobalBounds()))
			{
				life->decrease();
				danger.m_sprite.setPosition(rand()%700,rand()%700);	
			}
 	
 	
 	
 	
 	for(int i=0;i<10;i++)
 	if(alpha_1[i].isOfscreen(window))
 	{
 		
 			counter_2++;
 			if(counter_2==10)
 			e_1=false;
 	}
 	 counter_2=0;
 	for(int i=0;i<10;i++)
 	if(alpha_2[i].isOfscreen(window))
 	{
 		
 			counter_2++;
 			if(counter_2==10)
 			e_2=true;
 	}

 	counter_3=0;
 	if (e_2==true)
 	 for(int i=0;i<10;i++)
 	if(alpha_3[i].isOfscreen(window))
 	{
 		
 			counter_3++;
 			if(counter_3==10)
 			e_3=true;
 	}
 	counter_1=0;
 	if(e_3==true)
	for(int i=0;i<14;i++)
 	if(beta_1[i].isOfscreen(window))
 	{
 		
 			counter_1++;
 			if(counter_1==14)
 			e_4=true;
 	}
 	counter_1=0;
 	if(e_4==true)
 	{
 	for(int i=0;i<14;i++)
 	if(beta_2[i].isOfscreen(window))
 	{
 		
 			counter_1++;
 			if(counter_1==14)
 			e_5=true;
 	}
 	}
 	counter_1=0;
 	if (e_5==true)
 	{
 	for(int i=0;i<14;i++)
 	if(gamma[i].isOfscreen(window))
 	{
 		
 			counter_1++;
 			if(counter_1==14)
 			e_6=true;
 	}
 	}
 	if(e_6==true)
 	{
 	if(mons.isOfscreen(window))
 		e_7=true;
 	}
	///// finish tab
        while (window.pollEvent(e))
        {  
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
                window.close(); //close the game                        	    
        }
        
        ///pausing
     
        if (Keyboard::isKeyPressed(Keyboard::P)) 
         {  pausing=true;
         
        } 
        ///Resume
        if (Keyboard::isKeyPressed(Keyboard::O)) 
         {  pausing=false;
         
        }
        //Exit 
        if(Keyboard::isKeyPressed(Keyboard::E))
        {
       	
        Event::Closed;
            window.close();
        }
           
        if(pausing==true)
        continue;
        
       //Movement
        if (Keyboard::isKeyPressed(Keyboard::Left)) //If left key is pressed
            player->move("l");    // Player will move to left
	if (Keyboard::isKeyPressed(Keyboard::Right)) // If right key is pressed
            player->move("r");  //player will move to right
	if (Keyboard::isKeyPressed(Keyboard::Up)) //If up key is pressed
            player->move("u");    //playet will move upwards
	if (Keyboard::isKeyPressed(Keyboard::Down)) // If down key is pressed
            player->move("d");  //player will move downwards
       
        if (Keyboard::isKeyPressed(Keyboard::S)) 
         {   player->move("s");  
            rotation_b =true;
            rotation_a=false;
        }
        
        if (Keyboard::isKeyPressed(Keyboard::A)) 
         {   player->move("a");  
            rotation_a =true;
            rotation_b=false;
        }
        
        if (Keyboard::isKeyPressed(Keyboard::D)) 
         {   player->move("d");  
            rotation_a =false;
            rotation_b=false;
        }
        while (player->getX() < 0.f) 
        player->movement_1(800);
     
	while (player->getX() > 800.f) 
        player->movement_1(-800);
        
      	if (player->getY() < 0.f) 
        player->movement_2(800);
     
	if (player->getY() > 800.f) 
        player->movement_2(-800);
        
      	/////Bullet
      	if(Keyboard::isKeyPressed(Keyboard::Space))
        {
        	
        	   player->fireBullet();
			
			
	}
	
	if(rotation_a==true)
        player->obj_b->sprite.move(-5,-5);
        
        else if(rotation_b==true)
        player->obj_b->sprite.move(5,-5);
     	
     	else
        player->obj_b->update(10);
       
       
      if(check_time>40)
        danger.update(5);
        
        
        	if(check_time>40&&c1==0)
	{
	dx[0]=pow(player->getX()-danger.getX(),2);
        dy[0]=pow(player->getY()-danger.getY(),2);
        dis[0]=sqrt(dx[0]+dy[0]);
	if(dis[0]<30 )
        {
       	life->decrease();
	player->sprite.setPosition(340,680);
	danger.m_sprite.setPosition(1000,1000);
	danger_2==true;
	}
	else 
	danger_2==false;
	
	if(danger_2==false)
	score+=50;
	c1=1;
	}
	
        
      //BetaInvader Bullet Fire
        if(e_3==true)
        {
      	for(int i=0;i<14;i++)
      	if(time_2[i]>=time_taken)
	{
	beta_1[i].bombs->update(0.3);
        if(beta_1[i].bombs->gY()>780)
        {
        time_2[i]=0;
        beta_1[i].Fire();
        }
        }
        if(e_4==true)
       	for(int i=0;i<14;i++)
      	if(time_2[i]>=time_taken)
	{
	beta_2[i].bombs->update(0.3);
        if(beta_2[i].bombs->gY()>780)
        {
        time_2[i]=0;
        beta_2[i].Fire();
        }
        }
           }           
          //time_taken
        for(int i=0;i<14;i++)
        time_2[i]+=1;
      
        
        
         for(int i=0;i<14;i++)
        {
        dx[i]=pow(beta_1[i].bombs->gX()-player->getX(),2);
        dy[i]=pow(beta_1[i].bombs->gY()-player->getY(),2);
        dis[i]=sqrt(dx[i]+dy[i]);
        }
        ///Bound Check 
            
        if(e_3==true || e_4==true)
        for(int i=0;i<14;i++)
        if(dis[i]<60)
        {
        if(check_time-delay>5000)
        {
        delay=check_time;
        life->decrease();
        }
        player->a-=5;
        p_destroy.setPosition(player->getX(),player->getY());
        window.draw(p_destroy);
        break;
        
        }
      
      //Health Decrease
        for(int i=0;i<10;i++)
        {
        dx[i]=pow(player->getX()-alpha_1[i].getX(),2);
        dy[i]=pow(player->getY()-alpha_1[i].getY(),2);
        dis[i]=sqrt(dx[i]+dy[i]);
        }
        for(int i=0;i<10;i++)
	if(dis[i]<50)
        {
        life->decrease();
        alpha_1[i].sprite.setPosition(1000,1000);
	player->sprite.setPosition(340,680);
	}
	
	
	for(int i=0;i<10;i++)
        {
        dx[i]=pow(player->getX()-alpha_2[i].getX(),2);
        dy[i]=pow(player->getY()-alpha_2[i].getY(),2);
        dis[i]=sqrt(dx[i]+dy[i]);
        }
	if(e_1==false)
	for(int i=0;i<10;i++)
	if(dis[i]<50)
        {
        life->decrease();
	player->sprite.setPosition(340,680);
	alpha_2[i].sprite.setPosition(1000,1000);
	}
      
      	if(e_1==true)
	for(int i=0;i<10;i++)
	{
		alpha_1[i].sprite.move(0,0.3);
	}

	if(e_1==false)
	for(int i=0;i<10;i++)
	{
		alpha_2[i].sprite.move(0,0.3);
	}
     	if(e_2==true)
     	for(int i=0;i<10;i++)
	{
		alpha_3[i].sprite.move(0,0.3);
	}
	if(ad.checkCollision(player->getGlobalBounds()))
	{
	life->increase();
	ad.m_sprite.setPosition(rand()%700,rand()%700);	
	}
	
	if(e_2==true)
        {
	for(int i=0;i<10;i++)
       if(player->obj_b->getGlobalBounds().intersects(alpha_3[i].getGlobalBounds()))
        {
        destroy.setPosition(alpha_3[i].X,alpha_1[i].Y);
        alpha_3[i].sprite.move(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=10;
        }
        }
        
	if(e_3==true)
	{
	for(int i=0;i<14;i++)
	if(player->obj_b->getGlobalBounds().intersects(beta_1[i].getGlobalBounds()))
        {
        destroy.setPosition(beta_1[i].gtX(),beta_1[i].gtY());
        beta_1[i].shape.setPosition(1000,1000);
        beta_1[i].bombs->shape.setPosition(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=20;
        }}
        if(e_4==true)
        {
	for(int i=0;i<14;i++)
	if(player->obj_b->getGlobalBounds().intersects(beta_2[i].getGlobalBounds()))
        {
        destroy.setPosition(beta_2[i].gtX(),beta_2[i].gtY());
        beta_2[i].shape.setPosition(1000,1000);
        beta_2[i].bombs->shape.setPosition(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=20;
        }
        }
        
        if(e_5==true)
        {
	for(int i=0;i<14;i++)
	if(player->obj_b->getGlobalBounds().intersects(gamma[i].getGlobalBounds()))
        {
        destroy.setPosition(gamma[i].gtX(),gamma[i].gtY());
        gamma[i].shape.setPosition(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=20;
        }
	
	}
	
	if(e_1==false)
	for(int i=0;i<10;i++)
       if(player->obj_b->getGlobalBounds().intersects(alpha_2[i].getGlobalBounds()))
        {
        destroy.setPosition(alpha_1[i].X,alpha_1[i].Y);
        alpha_2[i].sprite.move(-900,-1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=10;
        }
        
        
	for(int i=0;i<10;i++)
       if(player->obj_b->getGlobalBounds().intersects(alpha_1[i].getGlobalBounds()))
        {
        destroy.setPosition(alpha_1[i].X,alpha_1[i].Y);
        alpha_1[i].sprite.move(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=10;
        }
        
        
	window.draw(destroy);}
        	 			 	 if (life->lives == 0)
	{
		window.draw(game);
		finish = true;
	}
	        window.display();
	window.display();  
	Event e;
        if (finish)
        {
        	  while (window.pollEvent(e))
        {  
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
                window.close(); //close the game                        	    
        }
        
        ///pausinge
     
        if (Keyboard::isKeyPressed(Keyboard::E)) 
         {  window.close();
         
        } 
        }

	
	std::string scoreString = "Score: " + std::to_string(score);
        scoreText.setString(scoreString);
        
	////Display 
	
	window.clear(Color::Black); //clears the screen
	window.draw(background);  // setting background
	window.draw(player->sprite);   // setting player on screen
	

	if(check_time>40)

	if (danger.m_sprite.getPosition().y >= 3000)
	{
		danger.m_sprite.setPosition(100 + rand() % 400, -200);
	}
	window.draw(danger.m_sprite);
	
	window.draw(ad.m_sprite);
	window.draw(player->obj_b->sprite);
	
	
	
	////AlphaInvader Shapes
	if(e_1==true)
	for (int i = 0; i < 10	; i++) 
	{
            alpha_1[i].draw(window); 
        }
        if(e_2==false)
	for (int i = 0; i < 10	; i++) 
	{
            alpha_2[i].draw(window); 
        }
        if(e_2==true)
	for (int i = 0; i < 10	; i++) 
	{
            alpha_3[i].draw(window); 
        }
        
        
	//Beta Invader Shapes
	if(e_3==true)
	{
	for (int i = 0; i < 14	; i++)
	window.draw(beta_1[i].shape);}
	
	if(e_4==true){
	for (int i = 0; i < 14	; i++)
	window.draw(beta_2[i].shape);}
		
	if(e_5==true){
	for (int i = 0; i < 14	; i++)
	window.draw(gamma[i].shape);}
	
	if(e_3==true)
	{
        for (int i = 0; i < 14	; i++) 
	{
            window.draw(beta_1[i].bombs->shape); 
        }
        }if(e_4==true)
        {
               for (int i = 0; i < 14	; i++) 
	{
            window.draw(beta_2[i].bombs->shape); 
        }
        }
        if(e_6==true)
        {
        if(player->obj_b->getGlobalBounds().intersects(mons.getGlobalBounds()))
        {
        mons.shape.setPosition(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=20;
        }
        	mons.update(2);
        	window.draw(mons.shape);
        	window.draw(mons.lightningBeam->shape);
        }
        if(e_7==true)
        {
        if(player->obj_b->getGlobalBounds().intersects(drag.getGlobalBounds()))
        {
        drag.shape.setPosition(1000,1000);
        player->obj_b->sprite.move(-900,-1000);
        score+=20;
        }
        	drag.update(2, player->sprite.getPosition().x, player->sprite.getPosition().y);
        	window.draw(drag.shape);
        	window.draw(drag.fire->shape);
        }
	 window.draw(scoreText);
	 window.draw(life->texture);
	
}
     
      
      
}
}


};

