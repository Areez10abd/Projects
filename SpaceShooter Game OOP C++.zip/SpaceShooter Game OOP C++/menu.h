//Areez Abdullah 22i-1090 CS-D OOP Project
#include <SFML/Graphics.hpp>
#include "game.h"

class Menu
{
	public:
		//Default constructor
		Menu()
		{
			Game g; 
	   		 g.start_game();
		}

};
