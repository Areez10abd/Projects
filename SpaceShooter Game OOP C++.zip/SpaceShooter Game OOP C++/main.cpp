//Areez Abdullah 22i-1090 CS-D OOP Project
#include "menu.h"
#include <iostream>
using namespace std;

int main() 
{
   Menu m;
   return 0;
}

